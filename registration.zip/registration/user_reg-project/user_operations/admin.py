from django.contrib import admin
from .models import UserData
# Register your models here.
admin.site.register(UserData)