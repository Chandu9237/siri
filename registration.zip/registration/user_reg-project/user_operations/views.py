from django.shortcuts import render
from .models import UserData
#from django.http import HttpResponse

# Create your views here.
def register(request):
    if request.method == "POST":
        obj = UserData()
        obj.first_name = request.POST.get('first_name')
        obj.last_name = request.POST.get('last_name')
        obj.username = request.POST.get('username')
        obj.password1 = request.POST.get('password1')
        obj.password2 = request.POST.get('password2')
        obj.email = request.POST.get('email')
        
        
        
        if obj.password1 == obj.password2:
            if UserData.objects.filter(username=obj.username).exists():
                return render(request,'user_operations/register.html',{'msg':' username is already taken'})
            elif UserData.objects.filter(email=obj.email).exists():
                return render(request,'user_operations/register.html',{'msg1':'email is already taken'})
            else:
                obj.save()
                return render(request,'user_operations/login.html')


            
        else:
            
            return render(request,'user_operations/register.html',{'error':'recheck your password'})
        
    else:   
        return render(request,'user_operations/register.html')


def login(request):
    if request.method=="POST":
        if request.POST.get('username') and request.POST.get('password1'):
            try:
                user_data=UserData.objects.get(username=request.POST.get('username'),password1=request.POST.get('password1'),email=request.POST.get('email'))
                request.session['register'] = user_data.username
                return render(request,'user_operations/success.html',{'user_data':user_data})
            except:
                return render(request,'user_operations/login.html',{'error':'invalid credentials'})

    else:
        return render(request,'user_operations/login.html')



def logout(request):
    if request.method=="POST":
        if request.session['register']:
            del request.session['register']
        return render(request,'user_operations/login.html')